package com.example.p2pmessagingapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import yuku.ambilwarna.AmbilWarnaDialog;

public class MainActivity extends AppCompatActivity{

    EditText receivePortEditText, targetPortEditText, messageEditText, targetIPEditText;
    TextView chatText,chatText2;
    LinearLayout linearLayout;

    ServerClass serverClass;
    ClientClass clientClass;
    SendReceive sendReceive;
    String savedMsg="";
     int MESSAGE_READ=3;
    static final String TAG = "yourTag";

    int mDefaultColor;

    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};

    Handler handler=new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {

                if(MESSAGE_READ==3){
                    byte[] readBuff= (byte[]) msg.obj;

                    String tempMsg=new String(readBuff,0,msg.arg1);
                    chatText.setText("Received : "+tempMsg);
                    savedMsg+="Received :"+tempMsg+"\n";}


                else {
                    byte[] readBuff2 = (byte[]) msg.obj;

                    String tempMsg2 = new String(readBuff2, 0, msg.arg1);
                    linearLayout.setBackgroundColor(Integer.parseInt(tempMsg2));
                    MESSAGE_READ = 3;
                }

            return true;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        receivePortEditText = findViewById(R.id.serverPortEditText);
        targetPortEditText = findViewById(R.id.targetPortEditText);
        messageEditText = findViewById(R.id.messageEditText);
        targetIPEditText = findViewById(R.id.targetIPEditText);
        chatText = findViewById(R.id.chatText);
        chatText2 = findViewById(R.id.chatText2);

        mDefaultColor = ContextCompat.getColor(MainActivity.this, R.color.colorPrimary);
        linearLayout = findViewById(R.id.linearLayoutId);
        verifyStoragePermissions();
    }

    public void onStartClicked(View v){
        String port = receivePortEditText.getText().toString();
        serverClass = new ServerClass(Integer.parseInt(port));
        serverClass.start();
        Toast.makeText(this, "The server is started.", Toast.LENGTH_SHORT).show();
    }

    public void onConnectClicked(View v){
        String port = targetPortEditText.getText().toString();
        String ip = targetIPEditText.getText().toString();
        clientClass = new ClientClass(targetIPEditText.getText().toString(), Integer.parseInt(port));
        clientClass.start();
        Toast.makeText(this, "Connected", Toast.LENGTH_SHORT).show();
       // Intent intent= new Intent(MainActivity.this,Chat.class);
       // intent.putExtra("port",port);
       // intent.putExtra("ip",ip);
       // startActivity(intent);
    }

    public void onSendClicked(View v){
        String msg=messageEditText.getText().toString();
        sendReceive.write(msg.getBytes());
        chatText2.setText("Send : "+msg);
        savedMsg+="Send :"+msg+"\n";
        messageEditText.setText("");
    }
   // public void onSaveClicked(View v){
   //     writeToFile("All Masseges",savedMsg);
   // }

    public class ServerClass extends Thread{
        Socket socket;
        ServerSocket serverSocket;
        int port;

        public ServerClass(int port) {
            this.port = port;
        }

        @Override
        public void run() {
            try {
                serverSocket=new ServerSocket(port);
                //Log.d(TAG, "Waiting for client...");
                socket=serverSocket.accept();
               // Log.d(TAG, "Connection established from server");
                sendReceive=new SendReceive(socket);
                sendReceive.start();

            } catch (IOException e) {
                e.printStackTrace();
                Log.d(TAG, "ERROR/n"+e);
            }
        }
    }

    private class SendReceive extends Thread{
        private Socket socket;
        private InputStream inputStream;
        private OutputStream outputStream;

        public SendReceive(Socket skt)
        {
            socket=skt;
            try {
                inputStream=socket.getInputStream();
                outputStream=socket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            byte[] buffer=new byte[1024];
            int bytes;

            while (socket!=null)
            {
                try {
                    bytes=inputStream.read(buffer);
                    if(bytes>0)
                    {
                        handler.obtainMessage(MESSAGE_READ,bytes,-1,buffer).sendToTarget();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        public void write(final byte[] bytes) {
            new Thread(new Runnable(){
                @Override
                public void run() {
                    try {
                        outputStream.write(bytes);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();

        }
    }

    public class ClientClass extends Thread{
        Socket socket;
        String hostAdd;
        int port;

        public  ClientClass(String hostAddress, int port)
        {
            this.port = port;
            this.hostAdd = hostAddress;
        }

        @Override
        public void run() {
            try {

                socket=new Socket(hostAdd, port);
                Log.d(TAG, "Client is connected to server");

                sendReceive=new SendReceive(socket);
                sendReceive.start();

            } catch (IOException e) {
                e.printStackTrace();
                Log.d(TAG, "Can't connect from client/n"+e);
            }
        }
    }
    public void verifyStoragePermissions() {
        // Check if we have write permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                requestPermissions(
                        PERMISSIONS_STORAGE,
                        REQUEST_EXTERNAL_STORAGE
                );
            }
        }
    }
    private void writeToFile(String fileName, String data) {
        Long time= System.currentTimeMillis();
        String timeMill = " "+time.toString();
        File defaultDir = Environment.getExternalStorageDirectory();
        File file = new File(defaultDir, fileName+timeMill+".txt");
        FileOutputStream stream;
        try {
            stream = new FileOutputStream(file, false);
            stream.write(data.getBytes());
            stream.close();
            //showToast("file saved in: "+file.getPath());

        } catch (FileNotFoundException e) {
            Log.d(TAG, e.toString());
        } catch (IOException e) {
            Log.d(TAG, e.toString());
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.menu_layout,menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.fileMenu:
                return true;
            case R.id.backgroundMenu:
                openColorPicker();
                return true;
            case R.id.saveMenu:


                writeToFile("All Masseges",savedMsg);
                Toast toast1 = Toast.makeText(getApplicationContext(),
                        "saved",
                        Toast.LENGTH_SHORT);

                toast1.show();

                // showHelp();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void openColorPicker() {
        AmbilWarnaDialog colorPicker = new AmbilWarnaDialog(this, mDefaultColor, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onCancel(AmbilWarnaDialog dialog) {

            }

            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {
                mDefaultColor = color;
                linearLayout.setBackgroundColor(mDefaultColor);
                String msg1=Integer.toString(mDefaultColor);
                MESSAGE_READ=2;
                sendReceive.write(msg1.getBytes());
            }
        });
        colorPicker.show();
    }

}
